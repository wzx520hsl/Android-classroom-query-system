package com.wzx.buptschedule.base;

import android.view.View;

/**
 * 处理在FragmentActivity上的点击事件
 * 分发到相关的Fragment进行处理
 * @author sjy
 *
 */
public interface OnFrgActClick {
	void onOnFrgActClick(View view);
}
