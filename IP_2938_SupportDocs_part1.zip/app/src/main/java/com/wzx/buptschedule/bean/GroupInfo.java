package com.wzx.buptschedule.bean;

import com.avos.avoscloud.AVClassName;
import com.avos.avoscloud.AVObject;

import java.util.List;

/**
 * 群组信息
 * @author Harlan
 *
 */
@AVClassName(GroupInfo.GROUPINFO_CLASS)
public class GroupInfo extends AVObject{

	static final String GROUPINFO_CLASS = "GroupInfo";
	
	// 群组名字
	public static final String group_name = "group_name";
	// 群组成员
	public static final String group_peoples = "group_peoples";
	// 群组创建者
	public static final String group_creator = "group_creator";
	
	//创建者
	public String getCreatorName() {
		return this.getString(group_creator);
	}

	public void setCreatorName(String content) {
		this.put(group_creator, content);
	}
	
	//群组名
	public String getGroupName() {
		return this.getString(group_name);
	}

	public void setGroupName(String content) {
		this.put(group_name, content);
	}
	
	//群组成员
	public List<UserInfo> getGroupPeoples() {
		return (List<UserInfo>)this.getList(group_peoples, UserInfo.class);
	}
	public void setGroupPeoples(List<UserInfo> list) {
		this.put(group_peoples, list);
	}
	
}
