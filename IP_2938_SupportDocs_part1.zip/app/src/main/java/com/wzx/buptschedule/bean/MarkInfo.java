package com.wzx.buptschedule.bean;

import com.avos.avoscloud.AVClassName;
import com.avos.avoscloud.AVObject;

/**
 * 评论的数据结构
 * 
 * @author sjy
 * 
 */
@AVClassName(MarkInfo.MARK_CLASS)
public class MarkInfo extends AVObject implements Comparable<Object> {

	static final String MARK_CLASS = "MarkInfo";

	// 评论者
	private static final String MARKER = "marker";
	// 评论的教室
	private static final String MARKERMENU = "mark_menu";
	// 评论星级
	private static final String MARKRATE = "mark_rate";
	// 评论内容
	private static final String MARKCONTENT = "mark_content";

	public String getMarker() {
		return this.getString(MARKER);
	}

	public void setMarker(String content) {
		this.put(MARKER, content);
	}

	public String getMarkerMenu() {
		return this.getString(MARKERMENU);
	}

	public void setMarkerMenu(String content) {
		this.put(MARKERMENU, content);
	}

	public String getMarkRate() {
		return this.getString(MARKRATE);
	}

	public void setMarkRate(String content) {
		this.put(MARKRATE, content);
	}

	public String getMarkContent() {
		return this.getString(MARKCONTENT);
	}

	public void setMarkContent(String content) {
		this.put(MARKCONTENT, content);
	}

	@Override
	public int compareTo(Object o) {
		MarkInfo sdto = (MarkInfo) o;
		String rating = sdto.getMarkRate();
		return this.getMarkRate().compareTo(rating);
	}

}
