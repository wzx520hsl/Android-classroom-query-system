package com.wzx.buptschedule.base;

import android.os.Bundle;



/**
 * 用于Activity内部切换的fragment
 * 定义了一个回调用来通知宿主FragmentActivity执行相关处理
 * @author sjy
 *
 */
public class BaseSwitchFragment extends BaseFragment{

	/**
	 * 处理在Fragment上的事件回调
	 * 分发到宿主FragmentActivity进行处理
	 * @author wzx
	 *
	 */
	public interface FragmentCallBack {
		void fragmentCallBack(int targetID, Bundle data);
	}
	
	protected FragmentCallBack mFragmentCallBack;
	
	public BaseSwitchFragment newInstance(FragmentCallBack mFragmentCallBack){
		this.mFragmentCallBack =mFragmentCallBack;
		return this;
	}
	
	public void doFragmentBackPressed(){
		
	}
}
