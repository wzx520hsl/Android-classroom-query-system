package com.wzx.buptschedule.bean;

public class FreeRoom {

	//上课楼
	private String building;
	//上课教室
	private String room;
	
	
	public String getBuilding() {
		return building;
	}
	public void setBuilding(String building) {
		this.building = building;
	}
	public String getRoom() {
		return room;
	}
	public void setRoom(String room) {
		this.room = room;
	}
	
	

}
