package com.wzx.buptschedule.base;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;

import com.wzx.buptschedule.util.SingleToast;


/**
 * Handler 用来处理UI数据
 * @author sjy
 *
 */

public class BaseFragmentHandler extends Handler {
	
	protected static final String TAG = BaseFragmentHandler.class.getSimpleName();
	
	//处理传递String ID的Toast请求
	public static final int TOAST_INT = 0x3691;
	//处理传递String 值的Toast请求
	public static final int TOAST_STR = TOAST_INT+1;
	//网络请求有响应:请求成功(具体返回值千差万别)
	public static final int REQ_SUCC = TOAST_STR+1;
	//网络请求有响应:请求错误
	public static final int REQ_ERROR = REQ_SUCC+1;
	//网络请求无响应:网络错误
	public static final int NET_ERROR = REQ_ERROR+1;
	
	protected BaseFragment ui;
	
	public BaseFragmentHandler (BaseFragment ui) {
		this.ui = ui;
	}
	
	public BaseFragmentHandler (Looper looper) {
		super(looper);
	}
	
	/**
	 * 处理通用情况的结果反馈
	 * 通常网络请求成功的回调由调用界面自己使用，即REQ_SUCC
	 */
	@Override
	public void handleMessage(Message msg) {
		switch (msg.what) {
		case TOAST_INT:
			toastHint((Integer)msg.obj);
			break;
		case TOAST_STR:
			toastHint((String)msg.obj);
			break;
		default:
			break;
		}
	}
	
	public void toastHint (String msg) {
		SingleToast.showToast(ui.mAct, msg, 1500);
	}
	
	public void toastHint (int msgId) {
		SingleToast.showToast(ui.mAct, ui.getResources().getString(msgId), 1500);
	}
	
}