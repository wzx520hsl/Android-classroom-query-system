package com.avoscloud.leanchatlib.event;

/**
 * Created by wli on 15/8/24.
 */
public class MemberLetterEvent {
  public Character letter;
}
