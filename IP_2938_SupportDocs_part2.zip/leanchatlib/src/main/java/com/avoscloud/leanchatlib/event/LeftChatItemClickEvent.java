package com.avoscloud.leanchatlib.event;

/**
 * Created by wli on 15/8/27.
 */
public class LeftChatItemClickEvent {
  public String userId;
}
