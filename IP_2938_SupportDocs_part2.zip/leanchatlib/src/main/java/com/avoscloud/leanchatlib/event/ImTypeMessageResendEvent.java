package com.avoscloud.leanchatlib.event;

import com.avos.avoscloud.im.v2.AVIMMessage;

/**
 * Created by wli on 15/8/26.
 */
public class ImTypeMessageResendEvent {
  public AVIMMessage message;
}
