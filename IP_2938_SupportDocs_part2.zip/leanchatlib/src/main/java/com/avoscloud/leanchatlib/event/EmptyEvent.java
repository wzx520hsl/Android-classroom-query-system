package com.avoscloud.leanchatlib.event;

/**
 * Created by wli on 15/9/8.
 * 因为 register event 时必须要在 activity 中声明 onEvent，所以定义了此类
 * 仅供 AVBaseActivity onEvent 使用
 */
public class EmptyEvent {
}
